
from google.appengine.api import users

BlogAdmin = [users.User("simon.heisterkamp@gmail.com"),users.User("simon@heisterkamp.dk"),users.User("jorgensen@gmail.com")]
