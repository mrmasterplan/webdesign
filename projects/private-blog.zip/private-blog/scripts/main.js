function charge_comments(){
	$("div.comment-submit-container").each(function(i){
		if (!($(this).hasClass("invisible"))){$(this).addClass("invisible");}});
	$("div.comment-link-container").removeClass("invisible").find("a").removeClass("invisible");
	$("div.comment-comment-container").each(function(i){
		var container = this;
		$(this).find("a.comment-link-comment").click(function(e){
			e.preventDefault();
			$(container).find("div.comment-edit-container").addClass("invisible");
			$(container).find("div.comment-submit-container").toggleClass("invisible");
			if (!($(container).find("div.comment-submit-container").hasClass("invisible"))){
				$(container).find("div.comment-submit-container").find("textarea").focus();
			}
		});
		$(this).find("a.comment-link-edit").click(function(e){
			e.preventDefault();
			$(container).find("div.comment-submit-container").addClass("invisible");
			$(container).find("div.comment-edit-container").toggleClass("invisible");
			if (!($(container).find("div.comment-edit-container").hasClass("invisible"))){
				$(container).find("div.comment-edit-container").find("textarea").focus();
			}
		});
	});
	
	$("form.comment-submit-form").submit(function(){
		var body=$("textarea[name='commentbody']",this).val()
		var key=$("input[name='commentupon']",this).val()
		var form= this
		var parent=$(this).parents("div.comment-rest-container:first")
	
		if(body.length > 200){
			alert("Body must contain less than 200 characters.");
			return false;
		}
				
		console.log("commencing ajax send")
		$.ajax({
			type: "POST",
			url: "/submit-comment",
			data: {
				jsactive:"yes",
				commentbody:body,
				commentupon:key,
				},
			dataType: "html",
			success: function(res){
				console.log("ajax success executing")
				parent.append(res);
				$("textarea[name='commentbody']",form).attr("value","");
				
				charge_comments();
				
			},
	
		});
	
		return false;
	});
}
$(document).ready(function() {
	charge_comments()
	
	
	});
